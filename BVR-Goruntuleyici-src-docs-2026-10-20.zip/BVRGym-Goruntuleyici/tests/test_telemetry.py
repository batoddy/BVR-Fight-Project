import math
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from recordings import RecordingStore
from fixtures import read_exports
from telemetry import standard_temperature

HEADER='Time,Longitude,Latitude,Altitude,Roll (deg),Pitch (deg),Yaw (deg)'
AIR='F-16 (Blue) [Blue].csv'
MISSILE='AIM-120 AMRAAM (AIM0) [Blue].csv'
def file(name, rows, header=HEADER):
    return dict(name=name,text=header+'\n'+'\n'.join(rows))

class TelemetryTests(unittest.TestCase):
    def test_recorded_ned_velocity_is_used_even_when_position_and_heading_disagree(self):
        header='time_s,lon_deg,lat_deg,alt_m,yaw_deg,vel_north_fps,vel_east_fps,vel_down_fps'
        samples,_=read_exports([file(AIR,['0,18,59,5000,180,100,200,-50','1,18,59,5000,180,100,200,-50'],header)])
        for row in samples:
            self.assertEqual(row['velocity_source'],'recorded')
            self.assertAlmostEqual(row['velocity_north_mps'],30.48)
            self.assertAlmostEqual(row['velocity_east_mps'],60.96)
            self.assertAlmostEqual(row['velocity_up_mps'],15.24)

    def test_old_recordings_derive_vector_from_position_not_aircraft_attitude(self):
        header='time_s,lon_deg,lat_deg,alt_m,yaw_deg'
        samples,_=read_exports([file(AIR,['0,18,59,5000,0','2,18.01,59,5020,0'],header)])
        for row in samples:
            self.assertEqual(row['velocity_source'],'position')
            self.assertAlmostEqual(row['velocity_east_mps'],(samples[1]['east_m']-samples[0]['east_m'])/2)
            self.assertGreater(row['velocity_east_mps'],200)
            self.assertAlmostEqual(row['velocity_up_mps'],10)

    def test_single_sample_cannot_invent_direction_from_tas_or_yaw(self):
        samples,_=read_exports([file(AIR,['0,18,59,5000,0,0,90,250'],HEADER+',TAS')])
        self.assertIsNone(samples[0]['velocity_source'])
        self.assertTrue(all(samples[0][key] is None for key in ('velocity_north_mps','velocity_east_mps','velocity_up_mps')))

    def test_missile_velocity_fallback_uses_carrier_time_and_actual_displacement(self):
        samples,_=read_exports([file(MISSILE,['10,18,59,7000,0,0,0','12,18.02,59,7100,0,0,0'])])
        self.assertTrue(all(row['velocity_source']=='position' for row in samples))
        self.assertTrue(all(abs(row['velocity_up_mps']-50)<1e-9 for row in samples))
        self.assertGreater(samples[0]['velocity_east_mps'],500)

    def test_velocity_rotates_from_each_objects_local_frame_to_recording_frame(self):
        header='time_s,lon_deg,lat_deg,alt_m,vel_north_fps,vel_east_fps,vel_down_fps'
        samples,_=read_exports([file(AIR,['0,18,59,5000,0,100,0'],header),
                               file('F-16 (Hostile--red) [Red].csv',['0,19,59,5000,0,100,0'],header)])
        other=next(row for row in samples if row['team']=='red')
        self.assertAlmostEqual(other['velocity_east_mps'],30.48*math.cos(math.radians(1)))
        self.assertAlmostEqual(other['velocity_north_mps'],30.48*math.sin(math.radians(59))*math.sin(math.radians(1)))

    def test_speed_uses_true_elapsed_time_and_initial_sample_is_not_false_zero(self):
        samples,_=read_exports([file(AIR,['0,18,59,5000,0,0,90','0.2,18,59,5002,0,0,90','1.7,18,59,5017,0,0,90'])])
        for row in samples:
            # A climb at constant geocentric latitude is not quite along the
            # ellipsoid normal, so converting this legacy column to geodetic
            # leaves a sub-mm/s horizontal residual. Our own recorder records
            # geodetic latitude directly and has none.
            self.assertAlmostEqual(row['position_speed_mps'],10,delta=1e-4)
            self.assertIsNone(row['true_airspeed_mps'])
            self.assertIsNone(row['mach'])
            self.assertGreater(row['estimated_mach'],0)

    def test_recorded_tas_and_mach_take_precedence(self):
        samples,_=read_exports([file(AIR,['0,18,59,5000,0,0,90,250,0.8','2,18.01,59,5000,0,0,90,260,0.9'],HEADER+',TAS,Mach')])
        self.assertEqual([row['true_airspeed_mps'] for row in samples],[250,260])
        self.assertEqual([row['mach'] for row in samples],[.8,.9])
        self.assertTrue(all(row['position_speed_mps'] is None and row['estimated_mach'] is None for row in samples))

    def test_single_sample_stays_unknown_and_stationary_track_is_zero(self):
        samples,_=read_exports([file(AIR,['0,18,59,5000,0,0,90'])])
        self.assertIsNone(samples[0]['position_speed_mps'])
        samples,_=read_exports([file(AIR,['0,18,59,5000,0,0,90','1,18,59,5000,0,0,90'])])
        self.assertEqual(samples[0]['position_speed_mps'],0)
        self.assertEqual(samples[1]['estimated_mach'],0)

    def test_inventory_preserves_unfired_files_without_spawning_them(self):
        exports=[file(AIR,['0,18,59,5000,0,0,90','10,18.01,59,5000,0,0,90']),
                 file(MISSILE,['3,18,59,5000,0,0,90','5,18.01,59,5000,0,0,90']),
                 dict(name='AIM-120 AMRAAM (AIM1) [Blue].csv',text='\n')]
        samples,entities=read_exports(exports)
        self.assertEqual(len(entities),2)
        inventory=next(entity for entity in entities if entity['kind']=='aircraft')['inventory']
        self.assertEqual(len(inventory),2)
        self.assertEqual(inventory[0]['owner_id'],AIR)
        self.assertEqual((inventory[0]['record_start_s'],inventory[0]['record_end_s']),(3,5))
        self.assertFalse(inventory[1]['has_track'])
        self.assertTrue(all(row['id']!=inventory[1]['id'] for row in samples))
        with tempfile.TemporaryDirectory() as temporary:
            for export in exports:
                (Path(temporary)/export['name']).write_text(export['text'],encoding='utf-8')
            store=RecordingStore(temporary,settle_seconds=0);store.refresh()
            self.assertEqual(len(store.packet()['inventory'][AIR]),2)

    def test_multiple_same_team_aircraft_do_not_get_guessed_ownership(self):
        exports=[file(AIR,['0,18,59,5000,0,0,90']),
                 file('F-16 (Wingman) [Blue].csv',['0,18.1,59,5000,0,0,90']),
                 dict(name=MISSILE,text='\n')]
        _,entities=read_exports(exports)
        self.assertTrue(all(not entity['inventory'] for entity in entities if entity['kind']=='aircraft'))
        self.assertIsNone(entities[0]['unassigned_inventory'][0]['owner_id'])

    def test_standard_atmosphere_boundaries_and_limits(self):
        self.assertAlmostEqual(standard_temperature(11000),216.65)
        self.assertAlmostEqual(standard_temperature(20000),216.65)
        self.assertAlmostEqual(standard_temperature(32000),228.65)
        self.assertIsNone(standard_temperature(90000))

if __name__=='__main__':unittest.main()
