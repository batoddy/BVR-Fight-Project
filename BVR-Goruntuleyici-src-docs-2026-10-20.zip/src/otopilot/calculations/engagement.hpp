#pragma once

#include "model/aircraft.hpp"

// Füze ve taktik hesapları: WEZ, MAR, DOR. Hiçbir şey saklamaz; fonksiyonlar static.
//
// Geometry'den farkı: yalnız konuma değil, uçakların profiline (füze menzili, radar) de bakar.
// Bu yüzden Kinematics değil, Aircraft alır.
//   own:   bakan taraf
//   enemy: karşı taraf
// own.enemy.range_3d_m gibi Geometry sonuçları burada çağrılmadan önce doludur (World::update sırası).
class Engagement
{
public:
    // own'un WEZ'i: ilk füzesine (missiles[0]) göre, bu düşmana karşı.
    //   min_m: füzenin iç sınırı
    //   max_m: düşman bugünkü rotasını sürdürürse azami menzil; düşman bana geliyorsa
    //          (own.enemy.enemy_closing_mps +) uzar, kaçıyorsa kısalır
    // Füzesi yoksa {0, 0}: hiçbir menzil WEZ'de değil.
    static Wez wez(const Aircraft& own);

    // Bu menzil WEZ'in içinde mi: min_m < range_m < max_m
    static bool in_wez(double range_m, const Wez& wez);

    // m, Minimum Abort Range
    static double mar_m(const Aircraft& own, const Aircraft& enemy);

    // m, Desired Out Range
    static double dor_m(const Aircraft& own, const Aircraft& enemy);
};
