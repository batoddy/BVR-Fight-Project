#include "calculations/engagement.hpp"

Wez Engagement::wez(const Aircraft& own)
{
    Wez result;
    if (own.missiles.empty())
    {
        return result;   // füzesi yok: {0, 0}
    }

    const MissileProfile& missile = own.missiles[0].profile;
    result.min_m = missile.min_range_m;
    result.max_m = missile.max_range_m;

    // Füze uçarken düşman bana doğru gelirse menzil uzar, kaçarsa kısalır.
    if (missile.speed_mps > 0.0)
    {
        double flight_time_s = missile.max_range_m / missile.speed_mps;
        result.max_m += own.enemy.enemy_closing_mps * flight_time_s;
    }

    return result;
}

bool Engagement::in_wez(double range_m, const Wez& wez)
{
    return range_m > wez.min_m && range_m < wez.max_m;
}

double Engagement::mar_m(const Aircraft& own, const Aircraft& enemy)
{
    // TODO. Düşmanın füze menzili (enemy.profile), benim hızım, kapanma ...
    (void)own;
    (void)enemy;
    return 0.0;
}

double Engagement::dor_m(const Aircraft& own, const Aircraft& enemy)
{
    // TODO
    (void)own;
    (void)enemy;
    return 0.0;
}
