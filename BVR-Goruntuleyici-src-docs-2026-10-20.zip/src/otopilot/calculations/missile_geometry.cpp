#include "calculations/missile_geometry.hpp"
#include "calculations/geometry.hpp"

double MissileGeometry::range_m(const Missile& missile, const Aircraft& target)
{
    return Geometry::range_3d_m(missile.kinematics, target.kinematics);
}

double MissileGeometry::closure_mps(const Missile& missile, const Aircraft& target)
{
    return Geometry::closure_mps(missile.kinematics, target.kinematics);
}

double MissileGeometry::time_to_go_s(double range_m, double closure_mps)
{
    if (closure_mps <= 0.0)
    {
        return -1.0;   // yaklaşmıyor: hedefe hiç varmaz
    }
    return range_m / closure_mps;
}

bool MissileGeometry::pitbull(const Missile& missile, double range_m)
{
    double pitbull_range_m = missile.profile.pitbull_range_m;
    return pitbull_range_m > 0.0 && range_m < pitbull_range_m;
}
Ned MissileGeometry::los_m(const Missile& missile, const Aircraft& target)
{
    return Geometry::los_m(missile.kinematics,target.kinematics);
}
