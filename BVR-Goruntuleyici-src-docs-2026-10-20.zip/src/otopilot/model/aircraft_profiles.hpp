#pragma once

#include <map>
#include <stdexcept>
#include <string>
#include <vector>
#include "model/missile_profiles.hpp"

struct AltitudeFactor
{
    double altitude_m; // m, tablodaki irtifa noktası
    double factor;     // birimsiz, out dönüş yarıçapının çarpanı
};

// Uçak tipinin sabit özellikleri. Simülasyondan gelmez; burada elle doldurulur.
// Yeni özellik: alanı struct'a, değerini tabloya aynı sırada yaz.
struct AircraftProfile
{
    std::string name;

    // Füze yükü: slot sırasıyla tipler. Python yalnız füze SAYISINI verir; tipleri buradan gelir.
    // Python'daki sayı (scenario.yaml ammo) kadar slot bu listenin başından alınır.
    std::vector<MissileProfile> loadout;

    double max_mach = 0;               // birimsiz
    double max_g = 0;                  // g

    // WEZ burada değil: füzenin özelliği. Menzil missile_profiles.hpp'de, WEZ Engagement::wez'de hesaplanır.

    double radar_range_m = 0;          // m, algılama menzili
    double radar_gimbal_deg = 0;  // derece, yarım açı: burundan sağa VE sola tarama açısı (60 = ±60)

    double out_g = 0.0; // g, yaklaşık out dönüşünde kullanılan yük faktörü
    std::vector<AltitudeFactor> out_distance_factor; // irtifa artan sırada
};

// Değerlerin kaynağı:
//   F16  max_mach, max_g, radar: açık kaynak (F-16C Block 50/52, AN/APG-68).
//   Su57, CustomAircraft: tamamen örnek. Fizik modeli her tipte F-16.
//   Out katsayıları: yaklaşık simülasyon ayarları; ölçülmüş performans verisi değil.
//   İrtifa noktaları 10.000 / 20.000 / 30.000 ft'nin metre karşılıklarıdır.
//
// Anahtar: Python'dan gelen type (scenario.yaml). Değerler struct'taki sırayla.
inline const std::map<std::string, AircraftProfile>& aircraft_profiles()
{
    static const std::map<std::string, AircraftProfile> table = {
        //                   name               loadout (slot sırasıyla)        mach   g     radar   gimbal  out_g  out alt factors
        {"F16",            {"F-16",             {FOX3, FOX3, FOX3, FOX3},       2.05,  9.0,  80000,  60,     5.0,   {{3048.0, 1.0}, {6096.0, 1.2}, {9144.0, 1.5}}}},
        {"Su57",           {"Su-57",            {FOX3, FOX3, FOX3, FOX2, FOX2}, 2.0,   9.0, 100000,  60,     5.0,   {{3048.0, 1.0}, {6096.0, 1.2}, {9144.0, 1.5}}}},
        {"CustomAircraft", {"Ornek ozel ucak",  {FOX1, FOX1, FOX2, FOX2},       1.2,   4.0,  50000,  45,     4.0,   {{3048.0, 1.0}, {6096.0, 1.2}, {9144.0, 1.5}}}},
    };
    return table;
}

// Tipin profilini döndür. Tabloda yoksa anlaşılır hatayla dur.
inline const AircraftProfile& aircraft_profile(const std::string& type)
{
    const auto& table = aircraft_profiles();

    auto found = table.find(type);
    if (found == table.end())
    {
        throw std::runtime_error("Bilinmeyen ucak tipi: " + type + " (aircraft_profiles.hpp'ye ekle)");
    }

    return found->second;
}
