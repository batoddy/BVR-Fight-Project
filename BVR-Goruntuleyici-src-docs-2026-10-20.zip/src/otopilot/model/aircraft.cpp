#include "model/aircraft.hpp"
#include <algorithm>
#include <cmath>

double Aircraft::get_out_distance() const
{
    // TODO: dönerken artaca hızı da dikkate al
    

    const auto& p = profile.out_distance_factor;
    const double h = kinematics.altitude_m;
    double k;

    if (h <= p[0].altitude_m)
        k = p[0].factor;
    else if (h >= p[2].altitude_m)
        k = p[2].factor;
    else
    {
        // İrtifa ilk aralıktaysa 0–1, ikinci aralıktaysa 1–2 noktalarını kullan.
        const int i = h <= p[1].altitude_m ? 0 : 1;

        // Seçilen aralığın ne kadarında olduğumuzu bul: 0..1.
        const double t = (h - p[i].altitude_m) /
                         (p[i + 1].altitude_m - p[i].altitude_m);

        // Alt katsayıya, katsayı farkının t kadarını ekle.
        k = p[i].factor + t * (p[i + 1].factor - p[i].factor);
    }

    const double v = kinematics.tas_mps;
    const double n = profile.out_g;

    // Dairesel hareketin temel formülü: a = v² / R
    // Buradan dönüş yarıçapı: R = v² / a
    // Sabit irtifalı koordineli dönüşte yatay ivme: a = g * sqrt(n² - 1)
    // Sonuç: R = v² / (g * sqrt(n² - 1))
    // k: İrtifaya bağlı dönüş yarıçapı düzeltme katsayısı.
    return k * (v * v) / (9.81 * std::sqrt(n * n - 1.0));
}

bool Aircraft::fire_missile(const MissileProfile& type)
{
    // Emri verilmiş ama Python'un henüz uçurmadığı bir füzemiz varken yenisini verme:
    // iki emir aynı step'te giderse tek launch gider, eşleştirme kayar. Havadaki füze engel değil.
    int fired_count = 0;
    for (const Missile& m : missiles)
    {
        if (m.fired)
        {
            fired_count += 1;
            if (m.python_id.empty())
            {
                return false;   // emri verilmiş ama henüz uçmamış
            }
        }
    }

    for (Missile& m : missiles)
    {
        if (!m.fired && m.profile.name == type.name)
        {
            m.fired = true;
            m.fire_order = fired_count + 1;
            launch_order = true;
            return true;
        }
    }

    return false;   // o tipte atılmamış füze kalmadı
}

int Aircraft::missiles_left() const
{
    int count = 0;
    for (const Missile& m : missiles)
    {
        if (!m.fired)
        {
            count += 1;
        }
    }
    return count;
}

bool Aircraft::has_active_missile_against(const Aircraft& target) const
{
    for (const Missile& missile : missiles)
    {
        if (missile.in_flight() && missile.target_id == target.id)
        {
            return true;
        }
    }

    return false;
}

const Missile* Aircraft::last_fired() const
{
    const Missile* last = nullptr;
    for (const Missile& m : missiles)
    {
        if (m.fired && (last == nullptr || m.fire_order > last->fire_order))
        {
            last = &m;
        }
    }
    return last;
}
