#pragma once

#include <string>

// Füze rehberlik tipi: atıştan sonra ne kadar destek gerektiğini belirler.
enum class MissileType
{
    Fox1,   // yarı aktif radar: atan uçağın radarı isabete kadar aydınlatmalı
    Fox2,   // kızılötesi: destek gerekmez, kısa menzil
    Fox3,   // aktif radar: pitbull'a (arayıcı aktif) kadar destek, sonra serbest
};

// Füze tipinin sabit özellikleri. Simülasyondan gelmez; burada elle doldurulur.
// Not: BVRGym her füzeyi AIM-120 fiziğiyle uçurur; tip yalnız C++ hesaplarında kullanılır.
struct MissileProfile
{
    std::string name;
    MissileType type = MissileType::Fox3;

    double max_range_m = 0;      // m, etkin menzil dış sınırı
    double min_range_m = 0;      // m, etkin menzil iç sınırı
    double speed_mps = 0;        // m/s, ortalama hız (uçuş süresi tahmini için)
    double pitbull_range_m = 0;  // m, Fox3: arayıcının kendi kilitlendiği füze-hedef mesafesi; diğerlerinde 0
};

// Üç füze. Koşulda doğrudan kullanılır:  world_.fighter.enemy.range_3d_m < FOX3.a_pole_m
// Atış:                                   world_.fighter.fire_missile(FOX3)
//
// Değerler ÖRNEK. AIM-120C menzili BVRGym'de ölçülen değer (kafa kafaya, 8000 m, 300 m/s).
//                                  name        type               max_m   min_m  speed_mps  pitbull_m
inline const MissileProfile FOX1 = {"AIM-7M",   MissileType::Fox1, 25000,  2000,  900,       0    };
inline const MissileProfile FOX2 = {"AIM-9X",   MissileType::Fox2, 10000,  500,   800,       0    };
inline const MissileProfile FOX3 = {"AIM-120C", MissileType::Fox3, 50000,  2000,  1000,      15000}; //110
