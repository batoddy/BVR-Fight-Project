#include "io/calculation_writer.hpp"

Json CalculationWriter::write(const World& world)
{
    Json data;
    data["aircraft"] = Json::array({to_json(world.fighter, world.hostile), to_json(world.hostile, world.fighter)});
    return data;
}

Json CalculationWriter::to_json(const Aircraft& own, const Aircraft& target)
{
    // Anahtar adları CSV sütun adı olur; birim adın sonunda (_m, _deg).
    Json j;
    j["id"] = own.id;
    j["target_id"] = target.id;
    j["phase"] = static_cast<int>(own.phase);   // 0 Hold, 1 Fire, 2 Crank, 3 Out, 4 o

    // Hesaplanan: World::update (EnemyInfo)
    j["range_2d_m"] = own.enemy.range_2d_m;
    j["range_3d_m"] = own.enemy.range_3d_m;
    j["bearing_deg"] = own.enemy.bearing_deg;
    j["ata_deg"] = own.enemy.ata_deg;
    j["aspect_deg"] = own.enemy.aspect_deg;
    j["los_north_m"] = own.enemy.los_m.north;
    j["los_east_m"] = own.enemy.los_m.east;
    j["los_down_m"] = own.enemy.los_m.down;
    j["closure_mps"] = own.enemy.closure_mps;
    j["enemy_closing_mps"] = own.enemy.enemy_closing_mps;
    j["enemy_in_my_wez"] = own.enemy.enemy_in_my_wez;
    j["me_in_enemy_wez"] = own.enemy.me_in_enemy_wez;
    j["mar_m"] = own.enemy.mar_m;
    j["dor_m"] = own.enemy.dor_m;

    // Sabit: profil. Görüntüleyici radar açısını ve WEZ'i bunlarla çizer.
    j["radar_gimbal_deg"] = own.profile.radar_gimbal_deg;   // yarım açı (60 = ±60)
    j["radar_range_m"] = own.profile.radar_range_m;
    j["wez_min_range_m"] = own.enemy.my_wez.min_m;   // ilk füzeye göre, bu step'in WEZ'i
    j["wez_max_range_m"] = own.enemy.my_wez.max_m;   // düşmanın yönüne göre değişir
    return j;
}
